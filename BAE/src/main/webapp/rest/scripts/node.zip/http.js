var HTTP = function(url) {
    $.ajax({url: url,
        type: "GET",
        dataType: "json",
        success: function(result){
        console.log(JSON.parse(result));
    }});
}